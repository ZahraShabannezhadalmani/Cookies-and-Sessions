﻿using ZShAssignment2.Entities;

namespace ZShAssignment2.Services
{
    public interface ICourseManagerService
    {
        public List<Course> GetAllCourses();
        public Course? GetCourseById(int id);
        public int AddCourse(Course lesson);

        public void UpdateCourse(Course lesson);

        public Student? GetStudentById(int courseId , int studentId);
        public void UpdateConfirmationStatu(int courseId, int studentId, EnrollmentConfirmationStatus status);
        public Course? AddStudentToCourseById(int courseId, Student student);

        public void SendEnrollmentEmailByEventId(int courseId, string scheme, string host);
    }
}
