﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ZShAssignment2.Entities;
using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Logging;

namespace ZShAssignment2.Services
{
    public class CourseManageService :
        ICourseManagerService
    {
        private readonly CourseManagerDbContext _courseManagerDbContext;
        private readonly IConfiguration _configuration;


        public CourseManageService(CourseManagerDbContext courseManagerDbContext, IConfiguration configuration)
        {
            _courseManagerDbContext = courseManagerDbContext;
            _configuration = configuration;
        }

        public List<Course> GetAllCourses()
        {

            return _courseManagerDbContext.Courses
                .Include(each => each.Students)
                .OrderByDescending(each => each.StartDate)
                .ToList();
        }

        public Course? GetCourseById(int id)
        {
            return _courseManagerDbContext.Courses
                 .Include(each => each.Students)
                 .FirstOrDefault(each => each.CourseId == id);
        }

        public int AddCourse(Course lesson)
        {
            _courseManagerDbContext.Courses.Add(lesson);
            _courseManagerDbContext.SaveChanges();

            return lesson.CourseId;
        }

        public void UpdateCourse(Course lessson) {
            _courseManagerDbContext.Courses.Update(lessson);
            _courseManagerDbContext.SaveChanges();
        }

        public Student? GetStudentById(int courseId, int studentId)
        {
            return _courseManagerDbContext.Students.Include(each => each.Course).FirstOrDefault(each => each.CourseId == courseId && each.StudentId == studentId);
        }

        public void UpdateConfirmationStatu(int courseId, int studentId,
            EnrollmentConfirmationStatus status)
        {
            var student = GetStudentById(courseId, studentId);
            if (student == null) return;

            student.Status = status;
            _courseManagerDbContext.SaveChanges();
        }
        public Course? AddStudentToCourseById(int courseId, Student student)
        {
            var lesson = GetCourseById(courseId);
            if(lesson == null) return null;

            lesson.Students?.Add(student);
            _courseManagerDbContext.SaveChanges();
            return lesson;
        }

        public void SendEnrollmentEmailByEventId(int courseId, string scheme, string host)
        {
            var lesson = GetCourseById(courseId);
            if(lesson == null) return;
            var students = lesson.Students.Where(each =>each.Status == EnrollmentConfirmationStatus.MessageNotSent)
                .ToList();

            try
            {
                var smtpHost = _configuration["SmtpSettings:Host"];
                var smtpPort = _configuration["SmtpSettings:Port"];
                var fromAddress = _configuration["SmtpSettings:FromAddress"];
                var fromPassword = _configuration["SmtpSettings:FromPassword"];

                using var smtpClient = new SmtpClient(smtpHost);
                smtpClient.Port = string.IsNullOrEmpty(smtpPort) ? 587 : Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(fromAddress, fromPassword);
                smtpClient.EnableSsl = true;

                foreach (var student in students)
                {
                    var responseUrl = $"{scheme}://{host}/events/{courseId}/enroll/{student.StudentId}";
                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress(fromAddress),
                        Subject = $"[Action required] Confirm \"{student?.Course?.CourseName}\"",
                        Body = CreateBody(student, responseUrl),
                        IsBodyHtml = true
                    };
                    if (student.StudentEmail == null) return;
                    mailMessage.To.Add(student.StudentEmail);

                    smtpClient.Send(mailMessage);

                    student.Status = EnrollmentConfirmationStatus.ConfirmationMessageSent;
                }
                _courseManagerDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        private string CreateBody(Student student, string reponseUrl)
        {
            return $@"
                    <h1>Hello {student.StudentName}:</h1>
                    <p>
                       Your request to enroll in the course {student.Course.CourseName}
                        in room {student.Course.RoomNumber}
                        starting {student.Course.StartDate}
                        with host {student.Course.InstructorName}
                    </p>
                    <p>
                        Please confrim you attendance
                    <a href={reponseUrl}>confirm your enrollment</a>
                    </p>
                    ";
        }
        }
    }

