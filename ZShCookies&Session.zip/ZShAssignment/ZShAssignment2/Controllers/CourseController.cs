﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ZShAssignment2.Entities;
using ZShAssignment2.Models;
using ZShAssignment2.Services;

namespace ZShAssignment2.Controllers
{
    public class CourseController : AbstractBaseController
    {
        private readonly ICourseManagerService
            _courseManagerService;

        public CourseController(ICourseManagerService courseManagerService)
        {
            
            _courseManagerService = courseManagerService;
            
        }

        [HttpGet("/courses")]
        public IActionResult List()
        {
            SetWelcome();

            var coursesViewModel = new CoursesViewModel()
            {
                Courses = _courseManagerService.GetAllCourses(),

            };
            return View(coursesViewModel);
        }

        [HttpGet("/courses/{id:int}")]
        public IActionResult Manage(int id)
        {
            SetWelcome();

            var lesson =
                _courseManagerService.GetCourseById(id);

            if(lesson == null) { return NotFound(); }

            var manageCourseViewModel = new ManageCourseViewModel()
            {
                Course = lesson,
                Student = new Student(),
                CountMessageNotSent = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.MessageNotSent),
                CountConfirmationMessageSent = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.ConfirmationMessageSent),
                CountConfirmed = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.EnrollmentConfirmed),
                CountDeclined = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.EnrollmentDeclined)
            };
            return View(manageCourseViewModel);
        }

        [HttpGet("/courses/{courseId:int}/enroll/{studentId:int}")]

        public IActionResult Enroll(int courseId, int studentId)
        {
            SetWelcome();
            var guest = _courseManagerService.GetStudentById(courseId, studentId);
            if (guest == null) { return NotFound(); };
            var enrollStudentViewModel = new EnrollmentStudentViewModel()
            {
                Student = guest,
            };
            return View(enrollStudentViewModel);
        }


		[HttpPost("/courses/{coursetId:int}/enroll/{studentId:int}")]
		public IActionResult Enroll(int courseId, int studentId, EnrollmentStudentViewModel enrollmentStudentViewModel)
		{
			SetWelcome();
			var student = _courseManagerService.GetStudentById(courseId, studentId);
			if (student == null) { return NotFound(); }
			if (ModelState.IsValid)
			{
				var status = enrollmentStudentViewModel.Response == "Yes"
					? EnrollmentConfirmationStatus.EnrollmentConfirmed
					: EnrollmentConfirmationStatus.EnrollmentDeclined;

				_courseManagerService.UpdateConfirmationStatu(courseId, studentId, status);
				return RedirectToAction("ThankYou", new { response = enrollmentStudentViewModel.Response });
			}
			else
			{
				enrollmentStudentViewModel.Student = student;
				return View(enrollmentStudentViewModel);
			}
		}


		[HttpGet("/courses/add")]
        public IActionResult Add()
        {
            SetWelcome();
            var courseViewModel = new CourseViewModel()
            {
                Course = new Course()
            };
            return View(courseViewModel);
        }

        [HttpPost("/courses/add")]
        public IActionResult Add(CourseViewModel courseViewModel)
        {
            SetWelcome();
            if(!ModelState.IsValid)
            {
                return View(courseViewModel);

                //add info
            }
            _courseManagerService.AddCourse(courseViewModel.Course);
            TempData["notify"] = $"{courseViewModel.Course.CourseName}  added successfully";
            TempData["className"] = "success";

            return RedirectToAction("Manage", new {id =courseViewModel.Course.CourseId});
        }

        [HttpGet("/courses/{id:int}/edit")]
        public IActionResult Edit(int id) 
        {
            SetWelcome();
            var lesson= _courseManagerService.GetCourseById(id);
            if(lesson==null)
                return NotFound();

            var courseViewModel = new CourseViewModel() { Course = _courseManagerService.GetCourseById(id) };
            return View(courseViewModel);
        }

        [HttpPost("/courses/{id:int}/edit")]
        public IActionResult Edit(int id,CourseViewModel courseViewModel)
        {
            SetWelcome();
            if(!ModelState.IsValid)
            {
                return View(courseViewModel);
            }

            _courseManagerService.UpdateCourse
                (courseViewModel.Course);
            TempData["notify"] =
                $"{courseViewModel.Course.CourseName}updated successfully";
            TempData["className"] = "info";

            return RedirectToAction("Manage", new { id });
        }

        [HttpGet("/thank-you/{response}")]
        public IActionResult ThankYou(string response)
        {
            SetWelcome() ;
            return View("ThankYou",response);
        }


        [HttpPost("/courses/{courseId:int}/add-guest")]
        public IActionResult AddStudent(int courseId, ManageCourseViewModel manageCourseViewModel)
        {
            SetWelcome();

            Course? lesson;

            if (ModelState.IsValid)
            {
                _courseManagerService.AddStudentToCourseById(courseId, manageCourseViewModel.Student);
                TempData["notify"] =
                    $"{manageCourseViewModel.Student.StudentName} added to guest list";
                TempData["className"] = "success";
                return RedirectToAction("Manage", new { id = courseId });
            }
            else
            {
                lesson = _courseManagerService.GetCourseById(courseId);

                if (lesson == null) return NotFound();

                manageCourseViewModel.Course = lesson;
                manageCourseViewModel.CountMessageNotSent = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.MessageNotSent);
                manageCourseViewModel.CountConfirmationMessageSent = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.ConfirmationMessageSent);
                manageCourseViewModel.CountConfirmed = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.EnrollmentConfirmed);
                manageCourseViewModel.CountDeclined = lesson.Students.Count(each => each.Status == EnrollmentConfirmationStatus.EnrollmentDeclined);

                return View("Manage", manageCourseViewModel);
            }
        }

        [HttpPost("/courses/{courseId:int}/enroll")]
        public IActionResult SendInvitation(int courseId)
        {
            _courseManagerService.SendEnrollmentEmailByEventId(courseId, Request.Scheme, Request.Host.ToString());
            return RedirectToAction("Manage", new { id = courseId });
        }
    }
}
