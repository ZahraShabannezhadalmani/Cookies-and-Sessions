﻿using System.ComponentModel.DataAnnotations;

namespace ZShAssignment2.Entities
{

    public class Course
    {
        //[key]
        public int CourseId { get; set; }

        [Required(ErrorMessage = "Please Enter Course's Name")]
        public string? CourseName { get; set; }

        [Required(ErrorMessage = "Please Enter Instructor's Name")]
        public string? InstructorName { get; set; }

        [Required(ErrorMessage = "What's your start date?")]
        public DateTime? StartDate { get; set; }

        [Required(ErrorMessage = "What's your room number?")]
        [RegularExpression(@"^\d[A-Z]\d{2}$", ErrorMessage = "Room number must be in the format:1C07")]
        public string? RoomNumber { get; set; }

        public List<Student>? Students { get; set; }


    }
}

