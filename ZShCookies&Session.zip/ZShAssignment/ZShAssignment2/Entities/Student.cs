﻿using System.ComponentModel.DataAnnotations;

namespace ZShAssignment2.Entities
{
        public enum EnrollmentConfirmationStatus
        {
            MessageNotSent,
            ConfirmationMessageSent,
            EnrollmentConfirmed,
            EnrollmentDeclined
        }

        public class Student
        {
            public int StudentId { get; set; }

            [Required(ErrorMessage = "What is the Course Name?")]
            public string? StudentName { get; set; }

            [Required(ErrorMessage = "Email is required")]
            [EmailAddress(ErrorMessage = "Email must be in a valid email address format")]
            public string? StudentEmail { get; set; }

            //Status
            public EnrollmentConfirmationStatus Status { get; set; } = EnrollmentConfirmationStatus.MessageNotSent;

            public int CourseId { get; set; }
            public Course? Course { get; set; }
        }
    }
