﻿using Microsoft.EntityFrameworkCore;

namespace ZShAssignment2.Entities
{
    public class CourseManagerDbContext : DbContext
    {
        public CourseManagerDbContext(DbContextOptions<CourseManagerDbContext> options) : base(options)
        {
        }

        public DbSet<Course> Courses { get; set; }
        public DbSet<Student> Students { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().Property(Student => Student.Status).HasConversion<string>().HasMaxLength(64);

            modelBuilder.Entity<Course>().HasData(
                new Course
                {
                    CourseId = 1,
                    CourseName = "Programming Microsoft Web Technologies",
                    InstructorName = "Peter Madziak",
                    StartDate = new DateTime(2023, 12, 18),
                    RoomNumber = "1C09"
                }
                );
            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = 1,
                    StudentName="Bart Simpson",
                    StudentEmail="peter.madziak@gmail.com",
                    CourseId=1
                    

                }
                );
        }



    }
    }


