﻿using ZShAssignment2.Entities;

namespace ZShAssignment2.Models
{
    public class ManageCourseViewModel
    {
        public Course? Course { get; set; }

        public Student? Student { get; set; }

        public int CountMessageNotSent { get; set; }
        public int CountConfirmationMessageSent { get; set; }
        public int CountConfirmed { get; set; }
        public int CountDeclined { get; set; }
    }
}
