﻿using ZShAssignment2.Entities;
namespace ZShAssignment2.Models
{
    public class CourseViewModel
    {
        public Course? Course { get; set; }
    }
}
