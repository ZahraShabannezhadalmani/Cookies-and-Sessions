﻿using ZShAssignment2.Entities;

namespace ZShAssignment2.Models
{
    public class CoursesViewModel
    {
        public List<Course>? Courses { get; set; }
    }
}
