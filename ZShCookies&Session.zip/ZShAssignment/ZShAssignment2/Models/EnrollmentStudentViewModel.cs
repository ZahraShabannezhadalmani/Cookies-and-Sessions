﻿using ZShAssignment2.Entities;

namespace ZShAssignment2.Models
{
    public class EnrollmentStudentViewModel
    {
        public Student? Student { get; set; }
        public string? Response { get; set; }
    }
}
